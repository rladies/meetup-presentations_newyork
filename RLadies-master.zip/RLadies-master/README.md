Files for RLadies projects

Data Visualization Workshop 8/17/2017
